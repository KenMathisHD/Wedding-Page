<?php

//  CRUD - CReate, Update, Delete

$path = $_SERVER['DOCUMENT_ROOT'];
$includes = $path . "/includes/";

?>
<?php include($includes . "phptop.php"); ?>  
<!DOCTYPE html>
<html>

<head>
    <title>Wedding Info</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>

    <nav class="navbar">
		<ul>
			<li><a href="">Home/R.S.V.P.</a></li>
			<li><a href="">Wedding Info</a></li>
		</ul>
	</nav>
    <section></section>            
    <footer></footer>


    <script src="/js/script.js"></script>
</body>

</html>
<?php include($includes . "phpbottom.php"); ?>  